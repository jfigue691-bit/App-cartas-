# VaultX Deck — Android APK Project

Native Android Studio project for the VaultX Deck trading-card collection app.

## Build in Android Studio

1. Open this folder in **Android Studio**.
2. Allow Android Studio to download/sync the Gradle and Android Gradle Plugin dependencies.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. The debug APK will be in:
   `app/build/outputs/apk/debug/app-debug.apk`

## Command line

With a JDK 17+ environment and Android SDK installed:

```bash
gradle :app:assembleDebug
```

or use Android Studio's Gradle sync/build buttons.

## App

The app is a native Android WebView shell around a self-contained offline HTML implementation. It keeps the collection in Android WebView local storage, so added/edited/deleted cards persist between launches.

Core features from the supplied VaultX Deck design:
- Collection dashboard
- Total value / card count / graded count
- Search
- Game and tag filters
- Sorting by value/name
- Add/edit/delete cards
- Card details
- Analytics by game
- Wishlist/Grail tab
- Local persistence
- Mobile-first dark UI
